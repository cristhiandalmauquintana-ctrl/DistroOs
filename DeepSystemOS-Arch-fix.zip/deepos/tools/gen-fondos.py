# Genera fondos: coleccion "olas" (nueva) y "clasico" (tu fondo regradeado) por tema y hora del dia
import math, random, sys, os
import numpy as np
from PIL import Image, ImageFilter
sys.path.insert(0, os.path.dirname(__file__))
from paletas import TEMAS, SLOTS, hex2rgb
OUT = sys.argv[1]; ORIG = sys.argv[2]; LOGO = sys.argv[3]
W, H = 1920, 1080
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(5)

# (brillo, calidez, estrella) por hora: color del cielo se mezcla con el acento del tema
SLOT = {
 "amanecer":  dict(top=0.30, hor=0.85, warm=(255,150,110), warm_k=0.38, stars=0.15, sun=(0.72,0.62), sunr=0.55),
 "dia":       dict(top=0.55, hor=1.00, warm=(255,255,255), warm_k=0.10, stars=0.0,  sun=(0.30,0.28), sunr=0.40),
 "atardecer": dict(top=0.28, hor=0.80, warm=(255,110,70),  warm_k=0.45, stars=0.25, sun=(0.80,0.66), sunr=0.60),
 "noche":     dict(top=0.07, hor=0.26, warm=(120,140,255), warm_k=0.12, stars=1.0,  sun=(0.78,0.22), sunr=0.28),
}
def mix(a, b, t): return a + (b - a) * t
def noise(shape, amp): return rng.normal(0, amp, shape)

def cielo(tema, slot):
    _, bg, bg2, acc, acc2, *_ = TEMAS[tema]
    bg, bg2, acc, acc2 = map(lambda c: np.array(hex2rgb(c), float), (bg, bg2, acc, acc2))
    s = SLOT[slot]; y = np.linspace(0, 1, H)[:, None, None]
    top = mix(bg, acc, s["top"]); hor = mix(bg2, acc2, s["hor"])
    hor = mix(hor, np.array(s["warm"], float), s["warm_k"])
    img = mix(top, hor, y ** 1.35) * np.ones((H, W, 3))
    # sol / luna
    xx, yy = np.meshgrid(np.linspace(0, 1, W), np.linspace(0, 1, H))
    cx, cy = s["sun"]; d = np.hypot((xx - cx) * (W / H), yy - cy)
    glow = np.exp(-(d / (0.16 * s["sunr"] * 2)) ** 2)[..., None]
    img = img + glow * (np.array(s["warm"], float) * 0.7 + 60) * (0.5 if slot != "noche" else 0.35)
    disc = (d < 0.035 * (1.0 if slot != "noche" else 0.8))[..., None]
    img = np.where(disc, mix(img, np.array([255, 250, 235.]), 0.92), img)
    # estrellas
    if s["stars"] > 0:
        n = int(420 * s["stars"])
        for _ in range(n):
            x = rng.integers(0, W); yv = rng.integers(0, int(H * 0.55)); a = rng.uniform(0.25, 1.0) * s["stars"]
            r = rng.choice([1, 1, 1, 2]); img[max(0,yv-r):yv+r, max(0,x-r):x+r] += 255 * a * np.array([0.9, 0.95, 1])
    return img, (bg, bg2, acc, acc2)

def olas(tema, slot):
    img, (bg, bg2, acc, acc2) = cielo(tema, slot)
    s = SLOT[slot]; x = np.linspace(0, 1, W)
    base_y = np.linspace(0.58, 0.92, 7)
    for i, by in enumerate(base_y):
        t = i / (len(base_y) - 1)
        yline = H * (by + 0.018 * np.sin(x * 2 * np.pi * (1.1 + 0.35 * i) + i * 1.7) + 0.010 * np.sin(x * 2 * np.pi * (2.7 + i) + i))
        mask = (np.arange(H)[:, None] >= yline[None, :])[..., None]
        deep = mix(mix(bg2, acc, 0.55), bg, t ** 0.8)
        deep = mix(deep, np.array(s["warm"], float), s["warm_k"] * 0.25 * (1 - t))
        shade = deep * (0.60 + 0.55 * s["hor"] * (1 - t)) * np.ones((H, W, 3))
        edge = np.clip(1 - (np.arange(H)[:, None] - yline[None, :]) / 22.0, 0, 1)[..., None]
        shade = shade + edge * mix(acc2, np.array([255, 255, 255.]), 0.5) * (0.20 + 0.25 * s["hor"])
        img = np.where(mask, mix(img, shade, 0.93), img)
    # marca discreta con el logo
    logo = Image.open(LOGO).convert("RGBA").resize((150, 150), Image.LANCZOS)
    im = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    a = logo.getchannel("A").point(lambda v: int(v * 0.38)); logo.putalpha(a)
    im.paste(logo, (W - 150 - 56, H - 150 - 56), logo)
    return im

def clasico(tema, slot):
    # Regradea tu fondo original: luminancia -> degradado con colores del tema; hora ajusta brillo y calidez
    _, bg, bg2, acc, acc2, fg, *_ = TEMAS[tema]
    src = Image.open(ORIG).convert("RGB").resize((W, H), Image.LANCZOS)
    L = np.asarray(src.convert("L"), float) / 255.0
    L = np.clip((L - 0.06) / 0.80, 0, 1)
    s = SLOT[slot]
    gain = {"amanecer": 1.15, "dia": 1.35, "atardecer": 1.1, "noche": 0.75}[slot]
    L = np.clip(L ** 0.75 * gain, 0, 1.2)
    stops = [(0.0, mix(np.array(hex2rgb(bg), float), np.array([0, 0, 0.]), 0.25)), (0.22, np.array(hex2rgb(bg2), float)),
             (0.55, np.array(hex2rgb(acc), float) * 0.85), (0.85, np.array(hex2rgb(acc2), float)), (1.2, np.array(hex2rgb(fg), float))]
    out = np.zeros((H, W, 3))
    for (a, ca), (b, cb) in zip(stops[:-1], stops[1:]):
        m = (L >= a) & (L <= b); t = ((L - a) / (b - a))[..., None]
        out = np.where(m[..., None], mix(ca, cb, t), out)
    # resplandor alrededor de lo brillante (el logo)
    bright = Image.fromarray((np.clip(L - 0.6, 0, 1) * 255 / 0.4).astype(np.uint8)).filter(ImageFilter.GaussianBlur(40))
    out += (np.asarray(bright, float) / 255.0)[..., None] * np.array(hex2rgb(acc2), float) * 0.55
    # degradado de hora: cielo calido arriba al amanecer/atardecer, oscuro de noche
    y = np.linspace(0, 1, H)[:, None, None]
    out = mix(out, np.array(s["warm"], float), s["warm_k"] * 0.45 * (1 - y) ** 1.5 * np.ones((H, W, 1)))
    if slot == "noche": out *= 0.82
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

total = 0
for tema in TEMAS:
    for slot in SLOTS:
        for nombre, fn in (("olas", olas), ("clasico", clasico)):
            im = fn(tema, slot)
            # grano ligero para evitar bandas en los degradados
            a = np.asarray(im, np.int16) + rng.integers(-2, 3, (H, W, 1))
            Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).save(f"{OUT}/{nombre}-{tema}-{slot}.jpg", quality=84, optimize=True, progressive=True)
            total += 1
print("fondos:", total)
