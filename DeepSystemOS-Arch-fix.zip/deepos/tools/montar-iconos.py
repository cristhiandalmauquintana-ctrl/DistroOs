# Monta los iconos de DeepSystemOS a partir de los recortes de la hoja de referencia del usuario,
# con un cambio de tono por tema, y los fondos "luna" (la foto del usuario) con el mismo tono.
import os, sys, numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
from paletas import TEMAS
CORT, OUT, LUNA, WALL = sys.argv[1:5]
SHIFT = {"oceano": 0, "neon": -32, "violeta": 48, "ambar": 178}   # grados de tono respecto al azul original

def tono(im, grados):
    if grados == 0: return im
    a = im.getchannel("A") if im.mode == "RGBA" else None
    h, s, v = im.convert("RGB").convert("HSV").split()
    h = Image.fromarray(((np.asarray(h).astype(int) + int(grados / 360 * 256)) % 256).astype(np.uint8))
    out = Image.merge("HSV", (h, s, v)).convert("RGB")
    if a is not None: out.putalpha(a)
    return out.convert("RGBA") if a is not None else out

def cuadrado(im, lado=128, margen=0.06):
    im = im.convert("RGBA"); w, h = im.size; k = (lado * (1 - 2 * margen)) / max(w, h)
    im = im.resize((max(1, round(w * k)), max(1, round(h * k))), Image.LANCZOS)
    c = Image.new("RGBA", (lado, lado), (0, 0, 0, 0)); c.alpha_composite(im, ((lado - im.width) // 2, (lado - im.height) // 2)); return c

NOMBRES = {  # archivo de salida: recorte
 "inicio": "vmark", "folder": "folder", "download": "folder", "terminal": "terminal", "store": "apps", "grid": "apps-circ",
 "gear": "gear", "power": "power", "home": "home", "search": "search", "lock": "lock", "user": "user", "globe": "globe",
 "trash": "trash", "refresh": "refresh", "logo": "logo-circ", "logo-cuad": "logo-cuad", "puntos": "puntos", "ballena": "ballena"}
for tema, g in SHIFT.items():
    os.makedirs(f"{OUT}/{tema}", exist_ok=True)
    for dest, src in NOMBRES.items():
        cuadrado(tono(Image.open(f"{CORT}/{src}.png").convert("RGBA"), g), 256 if dest in ("ballena", "inicio") else 128).save(f"{OUT}/{tema}/{dest}.png")
    cuadrado(tono(Image.open(f"{CORT}/logo-circ.png").convert("RGBA"), g), 64).save(f"{OUT}/tema-{tema}.png")
# iconos de categorias de la tienda (azul original)
CATS = ["search", "refresh", "puntos", "globe", "lock", "user", "home", "gear", "logo-cuad", "folder", "apps", "logo-circ"]
for i, c in enumerate(CATS, 1): cuadrado(Image.open(f"{CORT}/{c}.png").convert("RGBA"), 64).save(f"{OUT}/cat-{i}.png")
# fondo: la foto de luna del usuario, con el tono de cada tema
foto = Image.open(LUNA).convert("RGB").resize((1920, 1080), Image.LANCZOS)
for tema, g in SHIFT.items():
    tono(foto, g).save(f"{WALL}/luna-{tema}.jpg", quality=90, optimize=True, progressive=True)
if os.path.exists(f"{WALL}/luna.jpg"): os.remove(f"{WALL}/luna.jpg")
print("montaje ok")
