# Fuente unica de verdad de los temas de DeepSystemOS (el generador y los .conf salen de aqui)
TEMAS = {
  # nombre: (etiqueta, bg, bg2, acento, acento2, texto, apagado, alfa_panel)
  "oceano":  ("Oceano",  "#0B1F3A", "#143459", "#1E90E8", "#64B5F0", "#E6EEF7", "#7F93AA", 42),
  "neon":    ("Neon",    "#0A0B14", "#151633", "#00E5FF", "#FF2BD6", "#EAF6FF", "#7A86A8", 40),
  "violeta": ("Violeta", "#140B2E", "#271552", "#9B6BFF", "#FF7AC8", "#F1EAFF", "#9486B8", 42),
  "ambar":   ("Ambar",   "#1A1008", "#33200F", "#FFA826", "#FFD27A", "#FFF3E0", "#B39A7A", 42),
}
SLOTS = ["amanecer", "dia", "atardecer", "noche"]
def hex2rgb(h): h=h.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))
