# Logo de DeepSystemOS mas detallado (cola de ballena + olas + brillo), con supersampling
import math, random, sys
from PIL import Image, ImageDraw, ImageFilter, ImageChops
OUT = sys.argv[1]
S = 2048          # lienzo de trabajo
K = S/512.0       # escala respecto a las coordenadas del logo original (512)

def lerp(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(len(a)))
def catmull(pts, n=18, closed=True):
    out=[]; N=len(pts)
    for i in range(N if closed else N-3):
        p0,p1,p2,p3=[pts[(i+j-1)%N] if closed else pts[i+j] for j in range(4)]
        for k in range(n):
            t=k/n; t2=t*t; t3=t2*t
            out.append(tuple(0.5*((2*p1[d])+(-p0[d]+p2[d])*t+(2*p0[d]-5*p1[d]+4*p2[d]-p3[d])*t2+(-p0[d]+3*p1[d]-3*p2[d]+p3[d])*t3) for d in (0,1)))
    return out
def vgrad(w,h,stops):
    im=Image.new("RGBA",(w,h)); px=im.load()
    for y in range(h):
        t=y/(h-1); 
        for i in range(len(stops)-1):
            if stops[i][0]<=t<=stops[i+1][0]:
                u=(t-stops[i][0])/max(1e-6,stops[i+1][0]-stops[i][0]); c=lerp(stops[i][1],stops[i+1][1],u); break
        else: c=stops[-1][1]
        for x in range(w): px[x,y]=c+(255,) if len(c)==3 else c
    return im

# 1) fondo circular: cielo con degradado radial
sky=vgrad(S,S,[(0,(120,200,255)),(0.45,(86,176,248)),(1,(40,120,220))])
glow=Image.new("RGBA",(S,S),(0,0,0,0)); g=ImageDraw.Draw(glow)
g.ellipse((S*0.18,S*0.05,S*0.82,S*0.6),fill=(255,255,255,90)); glow=glow.filter(ImageFilter.GaussianBlur(S*0.08))
sky=Image.alpha_composite(sky,glow)
mask=Image.new("L",(S,S),0); ImageDraw.Draw(mask).ellipse((int(S*0.02),int(S*0.02),int(S*0.98),int(S*0.98)),fill=255)

# 2) cola de ballena (coordenadas del logo original, 512)
tail=[(133,88),(160,108),(196,122),(234,128),(256,138),(258,170),(252,215),(240,262),(228,284),
      (300,284),(294,248),(296,200),(298,160),(304,138),(326,126),(360,112),(384,98),(400,80),
      (376,88),(340,92),(312,100),(290,114),(276,124),(258,114),(228,100),(190,92),(158,88)]
poly=catmull([(x*K,y*K) for x,y in tail],14)
tm=Image.new("L",(S,S),0); ImageDraw.Draw(tm).polygon(poly,fill=255)
tail_g=vgrad(S,S,[(0,(255,255,255)),(0.40,(235,246,255)),(0.58,(190,225,250)),(1,(140,200,245))])
# sombra interior suave del lomo (da volumen)
vol=Image.new("L",(S,S),0); ImageDraw.Draw(vol).polygon(catmull([(x*K,y*K) for x,y in
   [(262,138),(266,170),(262,215),(250,262),(238,284),(252,284),(268,250),(278,210),(280,172),(276,140)]],10),fill=120)
vol=vol.filter(ImageFilter.GaussianBlur(S*0.006))
tail_g.putalpha(tm)
dark=Image.new("RGBA",(S,S),(40,110,200,255)); dark.putalpha(ImageChops.multiply(vol,tm))
sh=Image.new("RGBA",(S,S),(10,60,140,0)); sd=Image.new("L",(S,S),0)
ImageDraw.Draw(sd).polygon([(x*K+6*K,y*K+7*K) for x,y in poly],fill=70); sd=sd.filter(ImageFilter.GaussianBlur(S*0.012)); sh.putalpha(sd)

# 3) olas en bandas con degradado y espuma
def wave_band(y0,y1,amp,ph,cols,wl=1.15):
    m=Image.new("L",(S,S),0); d=ImageDraw.Draw(m)
    top=[(x,(y0+amp*math.sin((x/S)*math.pi*2*wl+ph))*K) for x in range(0,S+1,8)]
    bot=[(x,(y1+amp*math.sin((x/S)*math.pi*2*wl+ph+0.5))*K) for x in range(S,-1,-8)]
    d.polygon(top+bot,fill=255)
    band=vgrad(S,S,[(max(0,y0/512-0.05),cols[0]),(min(1,y1/512+0.05),cols[1])]); band.putalpha(m); return band,m
layers=[]
bands=[(272,288,9,0.2,[(255,255,255),(230,244,255)]),
       (292,330,11,0.9,[(70,170,250),(40,140,240)]),
       (336,372,12,1.7,[(30,130,235),(20,100,210)]),
       (378,420,12,2.5,[(25,105,205),(16,76,170)]),
       (426,470,11,3.3,[(16,78,170),(10,52,130)])]
canvas=Image.alpha_composite(sky,Image.new("RGBA",(S,S),(0,0,0,0)))
canvas=Image.alpha_composite(canvas,sh); canvas=Image.alpha_composite(canvas,dark.__class__.alpha_composite(tail_g,dark)) if False else Image.alpha_composite(canvas,tail_g)
canvas=Image.alpha_composite(canvas,dark)
for i,(y0,y1,a,p,c) in enumerate(bands):
    b,m=wave_band(y0,y1,a,p,c); canvas=Image.alpha_composite(canvas,b)
    # linea de espuma/brillo en el borde superior de cada banda
    edge=ImageChops.subtract(m,m.transform(m.size,Image.AFFINE,(1,0,0,0,1,6*K)))
    foam=Image.new("RGBA",(S,S),(255,255,255,0)); foam.putalpha(edge.point(lambda v:min(255,v*2)).filter(ImageFilter.GaussianBlur(1.5)))
    canvas=Image.alpha_composite(canvas,foam)
# gotas y destellos en el agua
random.seed(7); dr=ImageDraw.Draw(canvas)
for _ in range(26):
    x=random.randint(int(0.15*S),int(0.85*S)); y=random.randint(int(0.60*S),int(0.90*S)); r=random.randint(int(0.003*S),int(0.007*S))
    dr.ellipse((x-r,y-r,x+r,y+r),fill=(255,255,255,random.randint(60,150)))
# salpicadura junto a la cola
for dx,dy,r in ((318,268,7),(332,260,5),(344,266,4),(300,262,4)):
    dr.ellipse(((dx-r)*K,(dy-r)*K,(dx+r)*K,(dy+r)*K),fill=(255,255,255,200))
# destello de estrella (cuatro puntas) arriba a la derecha
def star(cx,cy,r,a=255):
    c=(255,255,255,a); k=r*0.18
    dr.polygon([(cx,cy-r),(cx+k,cy-k),(cx+r,cy),(cx+k,cy+k),(cx,cy+r),(cx-k,cy+k),(cx-r,cy),(cx-k,cy-k)],fill=c)
star(405*K,150*K,26*K); star(120*K,205*K,13*K,220); star(430*K,215*K,9*K,200)

# 4) recorte circular + aro con brillo + resplandor
out=Image.new("RGBA",(S,S),(0,0,0,0)); out.paste(canvas,(0,0),mask)
rim=Image.new("RGBA",(S,S),(0,0,0,0)); rd=ImageDraw.Draw(rim)
rd.ellipse((S*0.02,S*0.02,S*0.98,S*0.98),outline=(255,255,255,200),width=int(S*0.012))
rd.arc((S*0.06,S*0.06,S*0.94,S*0.94),215,285,fill=(255,255,255,150),width=int(S*0.01))
out=Image.alpha_composite(out,rim)
hl=Image.new("RGBA",(S,S),(0,0,0,0)); ImageDraw.Draw(hl).ellipse((S*0.16,S*0.05,S*0.84,S*0.42),fill=(255,255,255,18))
hl.putalpha(ImageChops.multiply(hl.getchannel("A"),mask)); out=Image.alpha_composite(out,hl)
halo=Image.new("RGBA",(S,S),(0,0,0,0)); ImageDraw.Draw(halo).ellipse((S*0.0,S*0.0,S*1.0,S*1.0),fill=(100,190,255,110))
halo=halo.filter(ImageFilter.GaussianBlur(S*0.03)); final=Image.alpha_composite(halo,out)
final=final.resize((1024,1024),Image.LANCZOS)
for n in (512,256,128,64,48,32):
    final.resize((n,n),Image.LANCZOS).save(f"{OUT}/logo-{n}.png")
print("logos ok")
