#!/bin/sh
# Comprueba que los paquetes de un catalogo existen en los repositorios de Arch (usa un contenedor).
#   tools/verificar-catalogo.sh assets/apps.tsv
CAT=$(readlink -f "${1:-assets/apps.tsv}")
ENG=$(command -v podman || command -v docker) || { echo "Falta podman o docker"; exit 1; }
sudo "$ENG" run --rm --network=host -v "$CAT":/cat.tsv:ro docker.io/library/archlinux:latest sh -c 'pacman -Sy >/dev/null 2>&1 || { echo "No pude actualizar la base de datos de paquetes"; exit 1; }; cut -f2 /cat.tsv | grep -v "^pip:" | while read -r p; do pacman -Si "$p" >/dev/null 2>&1 || echo "NO EXISTE: $p"; done; echo "Revision terminada."'
