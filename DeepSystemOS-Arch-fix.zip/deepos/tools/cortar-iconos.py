# Recorta los iconos de la hoja de referencia del usuario (PNG con alfa semitransparente de fondo) y limpia el fondo
import sys, numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage as ndi
HOJA, OUT = sys.argv[1], sys.argv[2]
im = Image.open(HOJA).convert("RGBA"); A = np.asarray(im).astype(float)
CAJAS = {  # nombre: (x0, y0, x1, y1)
 "terminal": (45, 95, 512, 482), "apps": (575, 95, 958, 482), "ballena": (1000, 140, 1510, 485),
 "home": (45, 568, 160, 682), "folder": (210, 568, 335, 688), "gear": (375, 568, 495, 688), "search": (538, 572, 642, 678),
 "power": (672, 578, 768, 672), "lock": (803, 572, 902, 678), "user": (943, 572, 1047, 678), "globe": (1078, 572, 1187, 682),
 "trash": (1225, 566, 1332, 688), "refresh": (1368, 568, 1502, 682),
 "logo-circ": (38, 748, 232, 932), "logo-cuad": (262, 762, 447, 932), "vmark": (498, 778, 657, 902),
 "apps-circ": (693, 763, 852, 922), "puntos": (878, 768, 1022, 918),
}
import os; os.makedirs(OUT, exist_ok=True)
for n, (x0, y0, x1, y1) in CAJAS.items():
    c = A[y0:y1, x0:x1].copy(); al = c[..., 3]
    # el icono es opaco (alfa ~250); el fondo/niebla tiene alfa bajo
    m = np.clip((al - 150) / (235 - 150), 0, 1)
    core = m > 0.5
    lab, k = ndi.label(core)
    if k == 0: print("sin icono", n); continue
    # conservar los componentes grandes (>= 3% del mayor)
    sizes = ndi.sum(core, lab, range(1, k + 1)); keep = [i + 1 for i, s in enumerate(sizes) if s >= 0.03 * sizes.max()]
    cm = np.isin(lab, keep)
    cm = ndi.binary_closing(cm, iterations=1)
    soft = ndi.binary_dilation(cm, iterations=3)                          # margen para el borde brillante
    alpha = np.where(cm, 1.0, np.where(soft, m * 0.9, 0.0))
    alpha = ndi.gaussian_filter(alpha, 0.8)
    out = np.dstack([c[..., :3], alpha * 255]).astype(np.uint8)
    img = Image.fromarray(out, "RGBA"); bb = img.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    img = img.crop(bb); img.save(f"{OUT}/{n}.png"); print(n, img.size)
