#!/usr/bin/env python3
"""Genera el logo de DeepSystemOS a color para fastfetch (medios bloques + 256 colores).
Uso: python3 tools/gen-logo-ansi.py [ancho_en_columnas]   (por defecto 48 -> 24 filas)"""
import sys, os
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
W = int(sys.argv[1]) if len(sys.argv) > 1 else 48
src = Image.open(os.path.join(HERE, "..", "assets", "logo-512.png")).convert("RGBA")
# recorta el halo transparente y escala (premultiplicado para no ensuciar los bordes)
bbox = src.getchannel("A").point(lambda a: 255 if a > 100 else 0).getbbox()
src = src.crop(bbox)
sz = (W, W)  # un pixel = media celda -> cuadrado
px = src.convert("RGBa").resize(sz, Image.LANCZOS).convert("RGBA")
if W % 2: raise SystemExit("usa un ancho par")

LV = [0, 95, 135, 175, 215, 255]
def c256(r, g, b):
    q = lambda v: min(range(6), key=lambda i: abs(LV[i] - v))
    ri, gi, bi = q(r), q(g), q(b)
    cube = (LV[ri], LV[gi], LV[bi]); cd = sum((x - y) ** 2 for x, y in zip(cube, (r, g, b)))
    gv = round((r + g + b) / 3); gi2 = max(0, min(23, round((gv - 8) / 10)))
    gray = 8 + 10 * gi2; gd = sum((gray - v) ** 2 for v in (r, g, b))
    return 232 + gi2 if gd < cd else 16 + 36 * ri + 6 * gi + bi

def pix(x, y):
    r, g, b, a = px.getpixel((x, y))
    return None if a < 110 else c256(r, g, b)

lines = []
for y in range(0, W, 2):
    out, cur = [], None
    for x in range(W):
        t, b = pix(x, y), pix(x, y + 1)
        if t is None and b is None: seq, ch = "\x1b[0m", " "
        elif t is None:             seq, ch = f"\x1b[0;38;5;{b}m", "▄"
        elif b is None:             seq, ch = f"\x1b[0;38;5;{t}m", "▀"
        else:                       seq, ch = f"\x1b[38;5;{t};48;5;{b}m", "▀"
        out.append(seq + ch)
    lines.append("".join(out) + "\x1b[0m")
dest = os.path.join(HERE, "..", "assets", "deepsystemos-logo.ansi")
open(dest, "w").write("\n".join(lines) + "\n")
print(f"OK {dest}: {W} columnas x {W//2} filas")
