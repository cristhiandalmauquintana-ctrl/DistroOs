# Resolucion: usa el modo preferido (el tamano de la ventana de QEMU); si no, 1280x720
OUT=$(xrandr 2>/dev/null | awk '/ connected/{print $1; exit}')
if [ -n "$OUT" ]; then
  xrandr --output "$OUT" --auto 2>/dev/null || xrandr --output "$OUT" --mode 1280x720 2>/dev/null
fi
command -v spice-vdagent >/dev/null 2>&1 && spice-vdagent &
deep-tema init
xrdb -merge "$HOME/.Xresources"
xsetroot -cursor_name left_ptr 2>/dev/null
setxkbmap "$(cat "$HOME/.config/deepos/teclado" 2>/dev/null || echo us)"
exec openbox-session
