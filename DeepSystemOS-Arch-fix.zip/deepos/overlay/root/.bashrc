[ -r /etc/profile.d/deepsystemos.sh ] && . /etc/profile.d/deepsystemos.sh
