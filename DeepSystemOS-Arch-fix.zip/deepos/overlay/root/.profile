[ -r /etc/profile.d/deepsystemos.sh ] && . /etc/profile.d/deepsystemos.sh
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  { echo "== entrada:"; ls /dev/input; } >/tmp/startx.log 2>&1
  startx -- -nolisten tcp -logverbose 5 >>/tmp/startx.log 2>&1
fi
