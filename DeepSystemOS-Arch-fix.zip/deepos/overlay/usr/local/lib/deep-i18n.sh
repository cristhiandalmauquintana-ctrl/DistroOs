# DeepSystemOS - traduccion por diccionario. El texto en espanol es la "clave".
#   t "Texto"    -> traduce al idioma elegido (si no hay traduccion, deja el original)
#   cmd | tl     -> igual, para lineas de stdin
#   tb "Texto"   -> al reves (idioma -> espanol): reconoce lo que el usuario eligio en un menu
# Diccionarios: /usr/share/deepsystemos/i18n/<idioma>.tsv  (espanol<TAB>traduccion)
DEEP_LANG=$(cat "${HOME:-/root}/.config/deepos/lang" 2>/dev/null); [ -n "$DEEP_LANG" ] || DEEP_LANG=es
_TSV="${DEEP_I18N:-/usr/share/deepsystemos/i18n}/$DEEP_LANG.tsv"
_i18n() {  # $1 = f (espanol->idioma) | b (idioma->espanol); lee stdin
  if [ "$DEEP_LANG" = es ] || [ ! -f "$_TSV" ]; then cat; return; fi
  LC_ALL=C awk -v mode="$1" -v tsv="$_TSV" '
    function isl(c) { return c != "" && (index("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", c) > 0 || c > "~") }
    function load(   line, p, a, b, x, i) {
      while ((getline line < tsv) > 0) {
        if (line ~ /^#/ || line == "") continue
        p = index(line, "\t"); if (p == 0) continue
        a = substr(line, 1, p - 1); b = substr(line, p + 1)
        if (mode == "b") { x = a; a = b; b = x }
        N++; i = N
        while (i > 1 && length(K[i-1]) < length(a)) { K[i] = K[i-1]; V[i] = V[i-1]; i-- }
        K[i] = a; V[i] = b
      }
      close(tsv); loaded = 1
      for (i = 1; i <= N; i++) { c = substr(K[i], 1, 1); FN[c]++; FI[c, FN[c]] = i }   # indice por 1a letra (orden: largas primero)
    }
    {
      if (!loaded) load()
      s = $0; out = ""; len = length(s); i = 1
      while (i <= len) {
        hit = 0; c0 = substr(s, i, 1)
        for (jj = 1; jj <= FN[c0]; jj++) {
          j = FI[c0, jj]; kl = length(K[j])
          if (substr(s, i, kl) != K[j]) continue
          if (isl(substr(K[j], 1, 1)) && i > 1 && isl(substr(s, i - 1, 1))) continue
          if (isl(substr(K[j], kl, 1)) && isl(substr(s, i + kl, 1))) continue
          out = out V[j]; i += kl; hit = 1; break
        }
        if (!hit) { out = out substr(s, i, 1); i++ }
      }
      print out
    }'
}
t()  { if [ $# -gt 0 ]; then printf '%s\n' "$*" | _i18n f; else _i18n f; fi; }
tl() { _i18n f; }
tb() { if [ $# -gt 0 ]; then printf '%s\n' "$*" | _i18n b; else _i18n b; fi; }
