# DeepSystemOS - compositor (generado por deep-tema): borde luminoso del color del tema
backend = "xrender";
vsync = false;
# Evita ventanas en blanco o transparentes en maquinas virtuales
use-damage = false;
# Esquinas redondeadas
corner-radius = 14;
rounded-corners-exclude = [ "window_type = 'dock'", "class_g = 'Rofi'", "window_type = 'desktop'" ];
# Sombras
shadow = true;
shadow-radius = 30;
shadow-opacity = 0.62;
shadow-color = "@ACC@";
shadow-offset-x = -30;
shadow-offset-y = -30;
shadow-exclude = [ "window_type = 'dock'", "window_type = 'desktop'", "_GTK_FRAME_EXTENTS@:c", "class_g = 'Rofi'" ];
# Transparencias: terminal negra translucida
inactive-opacity = 1.0;
frame-opacity = 1.0;
opacity-rule = [ "82:class_g = 'XTerm'", "82:class_g = 'xterm'" ];
# Transiciones suaves
fading = true;
fade-in-step = 0.06;
fade-out-step = 0.06;
detect-client-opacity = true;
detect-rounded-corners = true;
use-ewmh-active-win = true;
mark-wmwin-focused = true;
mark-ovredir-focused = true;
# Para desenfoque tipo cristal (solo con aceleracion 3D, en hardware real): cambia el backend a "glx" y descomenta
# blur-method = "dual_kawase"; blur-strength = 6;
