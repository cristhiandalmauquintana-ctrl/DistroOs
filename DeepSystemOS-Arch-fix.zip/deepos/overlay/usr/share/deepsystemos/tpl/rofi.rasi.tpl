/* generado por deep-tema (@LABEL@) */
* {
  bg: @BG@d4;
  bg-alt: @BG2@b8;
  fg: @FG@;
  muted: @MUTED@;
  accent: @ACC@;
  accent-light: @ACC2@;
  background-color: transparent;
  text-color: @fg;
}
window {
  background-color: @bg;
  border: 2px;
  border-color: @accent-light;
  border-radius: 20px;
  width: 640px;
  padding: 16px;
}
mainbox { children: [ inputbar, message, listview ]; spacing: 12px; }
inputbar { background-color: @bg-alt; border-radius: 14px; padding: 12px 14px; children: [ prompt, entry ]; spacing: 10px; }
prompt { text-color: @accent-light; }
entry { text-color: @fg; placeholder: "Escribe para buscar..."; placeholder-color: @muted; }
message { background-color: @bg-alt; border-radius: 12px; padding: 8px 12px; }
textbox { text-color: @muted; }
listview { lines: 9; columns: 1; scrollbar: false; spacing: 4px; fixed-height: false; }
element { padding: 9px 12px; border-radius: 12px; spacing: 12px; }
element normal.normal { background-color: transparent; }
element selected.normal { background-color: @accent; text-color: #FFFFFF; }
element-icon { size: 28px; }
