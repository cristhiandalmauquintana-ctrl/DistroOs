# DeepSystemOS - panel inferior generado por deep-tema (tema @LABEL@). No lo edites a mano.
# 1 panel (cristal) | 2 tarea | 3 tarea activa | 4 pastilla (lanzador, reloj, bandeja)
rounded = 22
border_width = 1
border_sides = TBLR
background_color = @BG@ @PANEL_A@
border_color = @ACC@ 55
background_color_hover = @BG@ @PANEL_A@
border_color_hover = @ACC2@ 70
background_color_pressed = @BG@ @PANEL_A@
border_color_pressed = @ACC2@ 70

rounded = 16
border_width = 1
border_sides = TBLR
background_color = @ACC@ 0
border_color = @ACC@ 0
background_color_hover = @ACC@ 28
border_color_hover = @ACC@ 60
background_color_pressed = @ACC@ 55
border_color_pressed = @ACC2@ 80

rounded = 16
border_width = 1
border_sides = TBLR
background_color = @ACC@ 52
border_color = @ACC2@ 85
background_color_hover = @ACC@ 66
border_color_hover = @ACC2@ 95
background_color_pressed = @ACC@ 52
border_color_pressed = @ACC2@ 95

rounded = 16
border_width = 1
border_sides = TBLR
background_color = @BG2@ 38
border_color = @ACC@ 28
background_color_hover = @BG2@ 55
border_color_hover = @ACC2@ 50
background_color_pressed = @BG2@ 70
border_color_pressed = @ACC2@ 60

panel_items = LTSC
panel_size = 100% 66
panel_position = bottom center horizontal
panel_margin = 14 10
panel_padding = 10 7 10
panel_background_id = 1
wm_menu = 1
panel_dock = 0
panel_layer = top
strut_policy = follow_size
autohide = 0

launcher_padding = 8 4 8
launcher_background_id = 4
launcher_icon_size = 46
launcher_icon_theme_override = 0
launcher_icon_asb = 100 0 0
launcher_item_app = /usr/share/applications/deep-menu.desktop
launcher_item_app = /usr/share/applications/deep-archivos.desktop
launcher_item_app = /usr/share/applications/deep-terminal.desktop
launcher_item_app = /usr/share/applications/deep-firefox.desktop
launcher_item_app = /usr/share/applications/deep-tienda.desktop
launcher_item_app = /usr/share/applications/deep-ajustes.desktop

taskbar_mode = single_desktop
taskbar_padding = 6 0 8
taskbar_background_id = 0
task_text = 1
task_icon = 0
task_centered = 1
task_maximum_size = 190 46
task_padding = 14 8 8
task_font = DejaVu Sans 10
task_background_id = 2
task_active_background_id = 3
task_font_color = @FG@ 85
task_active_font_color = #FFFFFF 100
task_iconified_font_color = @MUTED@ 100

systray_padding = 10 6 8
systray_background_id = 0
systray_icon_size = 24
systray_sort = ascending

time1_format = %I:%M %p
time1_font = DejaVu Sans Bold 15
time2_format = %b %d, %Y
time2_font = DejaVu Sans 9
clock_font_color = @FG@ 100
clock_padding = 16 4
clock_background_id = 4
