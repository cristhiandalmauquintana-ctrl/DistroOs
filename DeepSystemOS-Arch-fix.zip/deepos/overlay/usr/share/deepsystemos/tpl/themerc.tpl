# generado por deep-tema (@LABEL@)
border.width: 2
padding.width: 10
padding.height: 7
window.handle.width: 0
window.client.padding.width: 0
window.active.border.color: @ACC2@
window.inactive.border.color: @BG2@
window.active.client.color: @BG@
window.inactive.client.color: @BG@
window.active.title.bg: Flat Gradient Vertical
window.active.title.bg.color: @ACC@
window.active.title.bg.colorTo: @BG2@
window.inactive.title.bg: Flat Gradient Vertical
window.inactive.title.bg.color: @BG2@
window.inactive.title.bg.colorTo: @BG@
window.active.label.bg: Parentrelative
window.inactive.label.bg: Parentrelative
window.active.label.text.color: #FFFFFF
window.inactive.label.text.color: @MUTED@
window.label.text.justify: Left
window.active.handle.bg: Flat Solid
window.active.handle.bg.color: @BG2@
window.inactive.handle.bg: Flat Solid
window.inactive.handle.bg.color: @BG@
window.active.grip.bg: Flat Solid
window.active.grip.bg.color: @ACC@
window.inactive.grip.bg: Flat Solid
window.inactive.grip.bg.color: @BG2@
window.active.button.unpressed.bg: Parentrelative
window.active.button.unpressed.image.color: @FG@
window.active.button.pressed.bg: Flat Solid
window.active.button.pressed.bg.color: @ACC@
window.active.button.pressed.image.color: #FFFFFF
window.active.button.hover.bg: Flat Solid
window.active.button.hover.bg.color: @ACC@
window.active.button.hover.image.color: #FFFFFF
window.active.button.disabled.bg: Parentrelative
window.active.button.disabled.image.color: #4A5A70
window.active.button.toggled.unpressed.bg: Parentrelative
window.active.button.toggled.unpressed.image.color: @ACC2@
window.active.button.toggled.pressed.bg: Flat Solid
window.active.button.toggled.pressed.bg.color: @ACC@
window.active.button.toggled.pressed.image.color: #FFFFFF
window.active.button.toggled.hover.bg: Flat Solid
window.active.button.toggled.hover.bg.color: @ACC@
window.active.button.toggled.hover.image.color: #FFFFFF
window.inactive.button.unpressed.bg: Parentrelative
window.inactive.button.unpressed.image.color: @MUTED@
window.inactive.button.pressed.bg: Flat Solid
window.inactive.button.pressed.bg.color: @BG2@
window.inactive.button.pressed.image.color: @FG@
window.inactive.button.hover.bg: Flat Solid
window.inactive.button.hover.bg.color: @BG2@
window.inactive.button.hover.image.color: @FG@
window.inactive.button.disabled.bg: Parentrelative
window.inactive.button.disabled.image.color: #4A5A70
window.inactive.button.toggled.unpressed.bg: Parentrelative
window.inactive.button.toggled.unpressed.image.color: @MUTED@
window.inactive.button.toggled.pressed.bg: Flat Solid
window.inactive.button.toggled.pressed.bg.color: @BG2@
window.inactive.button.toggled.pressed.image.color: @FG@
window.inactive.button.toggled.hover.bg: Flat Solid
window.inactive.button.toggled.hover.bg.color: @BG2@
window.inactive.button.toggled.hover.image.color: @FG@
menu.border.width: 2
menu.border.color: @ACC@
menu.overlap: 0
menu.title.bg: Flat Solid
menu.title.bg.color: @BG2@
menu.title.text.color: @ACC2@
menu.title.text.justify: Left
menu.items.bg: Flat Solid
menu.items.bg.color: @BG@
menu.items.text.color: @FG@
menu.items.disabled.text.color: #4A5A70
menu.items.active.bg: Flat Solid
menu.items.active.bg.color: @ACC@
menu.items.active.text.color: #FFFFFF
menu.separator.color: @BG2@
menu.separator.width: 1
menu.separator.padding.width: 10
menu.separator.padding.height: 3
osd.border.width: 2
osd.border.color: @ACC@
osd.bg: Flat Solid
osd.bg.color: @BG@
osd.label.bg: Flat Solid
osd.label.bg.color: @BG@
osd.label.text.color: @FG@
osd.active.label.bg: Flat Solid
osd.active.label.bg.color: @BG2@
osd.active.label.text.color: #FFFFFF
osd.inactive.label.bg: Flat Solid
osd.inactive.label.bg.color: @BG@
osd.inactive.label.text.color: @MUTED@
osd.hilight.bg: Flat Solid
osd.hilight.bg.color: @ACC@
osd.unhilight.bg: Flat Solid
osd.unhilight.bg.color: @BG2@
