! generado por deep-tema (@LABEL@) - terminal negra translucida (la opacidad la pone picom)
XTerm*faceName: JetBrains Mono,DejaVu Sans Mono
XTerm*faceSize: 11
XTerm*background: #000000
XTerm*foreground: @FG@
XTerm*cursorColor: @ACC2@
XTerm*scrollBar: false
XTerm*cursorBlink: true
XTerm*boldMode: false
XTerm*colorBDMode: false
XTerm*saveLines: 4000
XTerm*internalBorder: 14
XTerm*termName: xterm-256color
XTerm*loginShell: true
XTerm*color0: #000000
XTerm*color8: #4A5568
XTerm*color1: #FF6B81
XTerm*color9: #FF9AA9
XTerm*color2: #4EE2A0
XTerm*color10: #8EF0C2
XTerm*color3: #FFC857
XTerm*color11: #FFE08A
XTerm*color4: @ACC@
XTerm*color12: @ACC2@
XTerm*color5: #C792FF
XTerm*color13: #E0B8FF
XTerm*color6: #3DDCF0
XTerm*color14: #9AF0FF
XTerm*color7: #D8DEE9
XTerm*color15: #FFFFFF

! Portapapeles: copiar al seleccionar y pegar con Ctrl+Shift+V o Shift+Insert (usan el portapapeles compartido)
XTerm*selectToClipboard: true
XTerm*VT100.translations: #override \n\
    Ctrl Shift <Key>V: insert-selection(CLIPBOARD) \n\
    Shift <Key>Insert: insert-selection(CLIPBOARD) \n\
    Ctrl Shift <Key>C: select-end(CLIPBOARD)

! Cursor visible
Xcursor.theme: Adwaita
Xcursor.size: 24
