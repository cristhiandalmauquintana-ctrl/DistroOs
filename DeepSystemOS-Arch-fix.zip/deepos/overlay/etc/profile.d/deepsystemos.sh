case $- in
  *i*)
    export EDITOR=nano
    # Colores en los comandos de siempre
    alias ls='ls --color=auto'; alias ll='ls -lAh --color=auto'; alias la='ls -A --color=auto'
    alias grep='grep --color=auto'; alias ..='cd ..'; alias ...='cd ../..'
    export LS_COLORS='di=1;38;5;39:ln=38;5;45:ex=1;38;5;78:*.zip=38;5;203:*.tar=38;5;203:*.gz=38;5;203:*.png=38;5;141:*.jpg=38;5;141:*.sh=1;38;5;78'
    if [ -n "$BASH_VERSION" ]; then
      HISTSIZE=5000; HISTCONTROL=ignoredups:erasedups; shopt -s histappend checkwinsize 2>/dev/null
      [ -r /usr/share/bash-completion/bash_completion ] && . /usr/share/bash-completion/bash_completion
      # Prompt de dos lineas: usuario@equipo, carpeta, rama de git y si el ultimo comando salio bien
      __deep_prompt() {
        local rc=$? d=$PWD h g="" st
        while [ -n "$d" ]; do
          if [ -f "$d/.git/HEAD" ]; then read -r h < "$d/.git/HEAD"; g="${h##*/}"; break; fi
          d=${d%/*}
        done
        if [ $rc -eq 0 ]; then st="\[\e[38;5;78m\]✔"; else st="\[\e[38;5;203m\]✘ $rc"; fi
        PS1="\[\e[6 q\]\[\e[38;5;39m\]╭─\[\e[0m\] \[\e[1;38;5;45m\]deep\[\e[38;5;244m\]@\[\e[1;38;5;33m\]deepsystemos\[\e[0m\] \[\e[38;5;244m\]en\[\e[0m\] \[\e[1;38;5;221m\]\w\[\e[0m\]${g:+ \[\e[38;5;141m\]⎇ $g\[\e[0m\]} $st\[\e[0m\]\n\[\e[38;5;39m\]╰─\[\e[1;38;5;45m\]❯\[\e[0m\] "
      }
      PROMPT_COMMAND=__deep_prompt
    else
      PS1="$(printf '\033[38;5;39m>\033[0m \033[1;36mdeep\033[0m@\033[1;34mdeepsystemos\033[0m')"' \033[1;33m\w\033[0m \$ '
      PS1=$(printf '%b' "$PS1")
      export PS1
    fi
    if [ -n "$DISPLAY" ] && [ -z "$DEEP_WELCOME_SHOWN" ]; then
      export DEEP_WELCOME_SHOWN=1
      deep-welcome
    fi
    ;;
esac
alias descargas='cd ~/Descargas'
