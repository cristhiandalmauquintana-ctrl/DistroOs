#!/bin/sh
# Arranca la ISO construida (out/*.iso) en QEMU.  SSH: ./ssh.sh
HERE=$(cd "$(dirname "$0")" && pwd)
ISO=$(ls -t "$HERE"/out/*.iso 2>/dev/null | head -n1)
[ -n "$ISO" ] || { echo "No hay ISO en out/. Corre ./build-iso.sh"; exit 1; }
for t in qemu-system-x86_64; do command -v $t >/dev/null || { echo "Falta '$t'. Instala: sudo apt install qemu-system-x86"; exit 1; }; done
C="$HERE/cache"; mkdir -p "$C"
VDA=""; qemu-system-x86_64 -chardev help 2>/dev/null | grep -q qemu-vdagent && VDA="-device virtio-serial-pci -chardev qemu-vdagent,id=vdagent,clipboard=on,mouse=off -device virtserialport,chardev=vdagent,name=com.redhat.spice.0"
KVM=""
if [ -w /dev/kvm ]; then KVM="-enable-kvm -cpu host"
else
  # Sin KVM QEMU emula la CPU por software: TODO va lento (incluido el raton). Acelera lo posible.
  KVM="-accel tcg,thread=multi -cpu max"
  echo ">> AVISO: no hay acceso a /dev/kvm -> emulacion lenta (el raton y la pantalla iran con retraso)."
  echo ">>        En Linux: sudo usermod -aG kvm \$USER (y reinicia sesion). En ChromeOS: usa un equipo/Crostini con KVM."
fi
# Audio: tarjeta Intel HDA en la VM y salida por el sonido del anfitrion (pulse > alsa > sdl)
AUD=""
for drv in pa alsa sdl; do
  qemu-system-x86_64 -audiodev help 2>/dev/null | grep -qw "$drv" && { AUD="-audiodev $drv,id=snd0,out.frequency=48000,out.buffer-length=100000 -device intel-hda -device hda-duplex,audiodev=snd0"; break; }
done
[ -n "$AUD" ] || AUD="-device intel-hda -device hda-duplex"
# Disco pequeno para que el idioma, tema y fondo se recuerden entre arranques
DISK=""; IMG="$C/persist.img"
if [ ! -f "$IMG" ] && command -v mkfs.ext4 >/dev/null 2>&1; then
  truncate -s 256M "$IMG" && mkfs.ext4 -q -F "$IMG" || rm -f "$IMG"
fi
[ -f "$IMG" ] && DISK="-drive file=$IMG,if=virtio,format=raw"
DISP=""
if qemu-system-x86_64 -display gtk,help 2>&1 | grep -q show-menubar; then
  ZF=""; qemu-system-x86_64 -display gtk,help 2>&1 | grep -q zoom-to-fit && ZF=",zoom-to-fit=on"
  DISP="-display gtk,show-menubar=off$ZF"
elif qemu-system-x86_64 -display help 2>&1 | grep -qx sdl; then DISP="-display sdl"; fi
# Telefono USB (opcional): ./telefono.sh lo elige
PH=""
if [ -f "$C/telefono" ]; then
  read PV PP < "$C/telefono"; HAY=0
  for d in /sys/bus/usb/devices/*; do
    [ "$(cat "$d/idVendor" 2>/dev/null)" = "$PV" ] && [ "$(cat "$d/idProduct" 2>/dev/null)" = "$PP" ] && HAY=1
  done
  if [ "$HAY" = 1 ]; then PH="-device usb-host,vendorid=0x$PV,productid=0x$PP"; echo ">> Telefono USB ($PV:$PP) conectado a la VM"
  else echo ">> Telefono configurado pero no esta conectado o compartido con Linux (sigo sin el)"; fi
fi
exec qemu-system-x86_64 -name DeepSystemOS $DISP $KVM -m "${RAM:-1024}" -smp 2 \
  -cdrom "$ISO" -boot order=d,menu=on,splash="$HERE/assets/splash.jpg",splash-time=2000 $DISK \
  -vga virtio $AUD $PH $VDA -device qemu-xhci -device usb-tablet -device usb-kbd \
  -nic user,model=virtio-net-pci,hostfwd=tcp::2222-:22
