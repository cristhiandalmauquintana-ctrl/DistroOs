# DeepSystemOS (base Arch Linux)

Arch Linux aligerado + Openbox + tint2 + rofi + Firefox. Entra solo como root (sesion en vivo, en RAM).
Atajos: Super+Enter terminal, Super+D lanzador, Super+E Firefox, clic derecho en el escritorio = menu.

## Construir la ISO
    sudo apt install podman qemu-system-x86 openssh-client
    ./build-iso.sh            # genera out/deepsystemos-*.iso  (la primera vez tarda y descarga ~1.5 GB)
    LITE=1 ./build-iso.sh     # version ligera sin Firefox ni herramientas extra
Necesita ~8 GB libres e internet. Los paquetes se guardan en cache/pkg (las siguientes construcciones son mas rapidas).
El script pide administrador (sudo) solo, porque archiso necesita montar cosas.
Libera espacio con: `podman system prune -a`

## Probar en QEMU
    ./quick-test.sh           # construye la ISO si falta y la arranca
    REBUILD=1 ./quick-test.sh # reconstruye despues de cambiar archivos
    ./run-iso.sh              # solo arrancar la ISO ya construida
Con /dev/kvm disponible va mucho mas fluido (sin KVM QEMU emula la CPU y todo es lento).

## Grabar en la USB
Sobre la ISO de out/: `sudo dd if=out/deepsystemos-*.iso of=/dev/sdX bs=4M status=progress oflag=sync`
(cambia sdX por tu USB; ojo: borra todo lo que tenga). En ChromeOS puedes usar Chromebook Recovery Utility o balenaEtcher.

## Estructura
- overlay/   archivos que se copian al sistema (Openbox, tint2, rofi, scripts deep-*, servicios systemd)
- assets/    wallpaper, logos, catalogo de la tienda (tools.tsv)
- packages.txt / packages-extra.txt   lo que instalamos; packages-remove.txt   lo que quitamos de la ISO oficial para aligerar
- build/inside.sh   arma el perfil de archiso (a partir de "releng") y construye la ISO

## Aligerado
- Se quita de la ISO oficial: herramientas de rescate y de sistemas de archivos raros, zsh, manuales, el firmware de todos los
  fabricantes (solo se incluye Intel, Realtek, MediaTek, Atheros, Broadcom, AMD y NVIDIA).
- Sin manuales ni documentacion (NoExtract en pacman.conf).
- La sesion en vivo reserva 2 GB de espacio de escritura para poder instalar programas desde la Tienda.

## Probar cambios sin esperar
- Cambios en scripts, menus, traducciones o configuracion: con la VM abierta, `./sync.sh` los copia en segundos (sin reconstruir). Cierra y abre la app para verlos.
- Cambios en paquetes (`packages*.txt`) o en `build/`: hay que reconstruir. Para ir rapido: `FAST=1 REBUILD=1 ./quick-test.sh` (SquashFS con zstd).
- La ISO final, sin FAST (xz, mas pequena): `REBUILD=1 ./quick-test.sh`.

## Tiendas
- Tienda de herramientas (`deep-tienda`, catalogo `assets/tools.tsv`) y Tienda de aplicaciones (`deep-tienda-apps`, catalogo `assets/apps.tsv`).
- Para anadir algo basta una linea `Categoria<TAB>paquete<TAB>descripcion` en el catalogo. Comprobar que los paquetes existen: `tools/verificar-catalogo.sh assets/apps.tsv`.

## Limpieza y compresion (ahorrar RAM y peso)
- `deep-limpieza` (temporizador cada 10 min y al terminar de instalar): borra la cache de paquetes pasados 10 min y la cache de programas (~/.cache) pasados 7 dias. Si la RAM o el disco pasan del 85 %, limpia todo sin esperar. Se ajusta en `/etc/deepsystemos/limpieza.conf`. `deep-limpieza ya|estado` a mano, o "* Limpiar espacio" en la Tienda.
- RAM comprimida: `zram-generator` (zstd, hasta la mitad de la RAM) + `vm.swappiness=100`. Comprobar: `zramctl` o `swapon --show`.
- Sin manuales, ayuda ni traducciones de programas salvo es/en/pt/fr/de (NoExtract), tambien para lo que se instale despues.
- Opcional (apagado): `COMPRIMIR_DIAS=7` en limpieza.conf comprime con zstd capturas y textos viejos de Descargas.
- Al instalar en disco (cuando exista el instalador): usar btrfs con `compress=zstd` para que el sistema ocupe bastante menos que la suma de sus paquetes.

## Paquetes
`deep-pkg` envuelve pacman (instalar, quitar, actualizar...). La Tienda y Ajustes lo usan. Si un paquete no existe en los
repositorios oficiales de Arch, la Tienda lo avisa al intentar instalarlo.

## SSH (para copiar/pegar comandos)
Con el OS corriendo en QEMU, desde otra terminal:
    ./ssh.sh       # shell dentro del OS
    ./diag.sh      # diagnostico de raton/teclado/Xorg/servicios
(solo funciona si cache/id_deep existia al construir la ISO; build-iso.sh la crea.)
