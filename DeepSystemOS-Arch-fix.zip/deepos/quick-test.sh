#!/bin/sh
# Prueba de DeepSystemOS en QEMU: si no hay ISO la construye (tarda la primera vez) y luego la arranca.
#   REBUILD=1 ./quick-test.sh     reconstruye la ISO aunque ya exista (despues de cambiar archivos)
#   LITE=1 ./quick-test.sh        version ligera
#   FAST=1 REBUILD=1 ./quick-test.sh   reconstruye en modo rapido (zstd): para ir probando cambios
#   RAM=3072                      memoria de la VM en MB
HERE=$(cd "$(dirname "$0")" && pwd)
if [ -n "$REBUILD" ] || ! ls "$HERE"/out/*.iso >/dev/null 2>&1; then
  "$HERE/build-iso.sh" || exit 1
fi
exec "$HERE/run-iso.sh"
