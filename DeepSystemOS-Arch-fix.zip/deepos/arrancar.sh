#!/bin/sh
# Arranca DeepSystemOS (lo usa el icono): abre la pantalla de carga y luego la VM.
# El progreso tambien queda en ~/deepsystemos.log
cd "$(dirname "$0")" || exit 1
exec ./quick-test.sh > "$HOME/deepsystemos.log" 2>&1
