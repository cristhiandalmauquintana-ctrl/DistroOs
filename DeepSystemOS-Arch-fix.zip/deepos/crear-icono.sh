#!/bin/sh
# Crea un icono "DeepSystemOS" en el menu de apps de ChromeOS para arrancar la VM con un clic.
# El progreso se guarda en ~/deepsystemos.log (mira con: tail -f ~/deepsystemos.log)
HERE=$(cd "$(dirname "$0")" && pwd)
chmod +x "$HERE"/*.sh
# avisos al abrir la app (notificaciones de ChromeOS)
command -v notify-send >/dev/null 2>&1 || { echo "Instalando avisos (libnotify-bin)..."; sudo apt-get install -y libnotify-bin >/dev/null 2>&1 || echo "(no pude instalar los avisos; el icono funciona igual)"; }
APPS="$HOME/.local/share/applications"; mkdir -p "$APPS"
# purgar iconos viejos de DeepSystemOS (y restos) antes de crear el nuevo
rm -f "$APPS"/deepsystemos*.desktop "$APPS"/DeepSystemOS*.desktop 2>/dev/null
rm -f "$HOME"/.local/share/icons/hicolor/*/apps/deepsystemos*.png 2>/dev/null
ICON="$HERE/assets/logo-512.png"; [ -f "$ICON" ] || ICON=$(ls "$HERE"/assets/logo-*.png 2>/dev/null | head -n1)
cat > "$APPS/deepsystemos.desktop" <<E2
[Desktop Entry]
Type=Application
Name=DeepSystemOS
Comment=Arrancar DeepSystemOS (QEMU)
Exec=$HERE/arrancar.sh
StartupNotify=false
Icon=$ICON
StartupWMClass=${WMCLASS:-qemu-system-x86_64}
Terminal=false
Categories=System;
E2
echo "Listo: busca 'DeepSystemOS' en el menu de apps. Progreso: tail -f ~/deepsystemos.log"
