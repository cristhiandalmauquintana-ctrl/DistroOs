#!/bin/sh
# Si el icono de la VM sigue sin unirse al de DeepSystemOS: abre la VM, ejecuta esto y haz clic en su ventana.
command -v xprop >/dev/null 2>&1 || sudo apt-get install -y x11-utils
echo "Haz clic en la ventana de la VM..."
C=$(xprop WM_CLASS | sed 's/.*= //')
echo "Clase detectada: $C"
N=$(echo "$C" | awk -F'"' '{print $4}'); [ -n "$N" ] || N=$(echo "$C" | awk -F'"' '{print $2}')
echo "Ejecuta ahora:  WMCLASS=$N ./crear-icono.sh"
