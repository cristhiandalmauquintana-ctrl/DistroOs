#!/bin/sh
# Entra al DeepSystemOS en QEMU por SSH (desde tu terminal normal)
D=$(cd "$(dirname "$0")" && pwd)
exec ssh -p 2222 -i "$D/cache/id_deep" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR root@localhost "$@"
