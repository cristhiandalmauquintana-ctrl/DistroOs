#!/bin/sh
# Mide (con la VM en marcha, ./run-iso.sh) lo que importa para los limites de DeepSystemOS:
#   RAM en reposo <= 1 GB | paquetes instalados <= 2.5 GB | y los paquetes mas pesados.
# Uso:  ./medir.sh        (desde otra terminal, con la VM abierta)
D=$(cd "$(dirname "$0")" && pwd)
"$D/ssh.sh" 'sh -s' <<'REMOTO'
echo "=== RAM (esperar 1-2 min tras arrancar el escritorio, sin abrir nada mas)"
free -m | awk '/^Mem:/{printf "RAM usada: %d MiB de %d MiB (objetivo: menos de 1024 MiB usados)\n",$3,$2}'
echo
pacman -Qi | awk '/^Name/{n=$3} /^Installed Size/{s=$4; u=$5; if(u=="KiB")s=s/1024; else if(u=="GiB")s=s*1024; else if(u=="B")s=s/1048576; print s, n}' > /tmp/pk.txt
echo "=== 25 paquetes mas pesados (instalados)"
sort -rn /tmp/pk.txt | head -25 | awk '{printf "%8.1f MiB  %s\n",$1,$2}'
echo
awk '{t+=$1} END{printf "=== TOTAL paquetes instalados: %.0f MiB (limite: 2.5 GB)\n",t}' /tmp/pk.txt
echo "=== Disco: /usr  $(du -sm /usr 2>/dev/null | cut -f1) MiB | /boot  $(du -sm /boot 2>/dev/null | cut -f1) MiB"
REMOTO
