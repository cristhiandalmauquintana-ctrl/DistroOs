#!/bin/sh
# Elige el telefono (USB) que se conecta a la VM para usar su internet por cable (anclaje USB).
#   ./telefono.sh          elegir el telefono
#   ./telefono.sh quitar   dejar de pasarlo a la VM
HERE=$(cd "$(dirname "$0")" && pwd); C="$HERE/cache"; mkdir -p "$C"
[ "$1" = quitar ] && { rm -f "$C/telefono"; echo "Listo: la VM ya no recibe el telefono."; exit 0; }
echo "Antes: en el telefono activa 'Anclaje USB' / 'Compartir internet por USB',"
echo "y en ChromeOS: Ajustes > Linux > Administrar dispositivos USB > activa el telefono."
echo
i=0; : > "$C/.usb.lst"
for d in /sys/bus/usb/devices/*; do
  [ -f "$d/idVendor" ] || continue
  [ "$(cat "$d/bDeviceClass" 2>/dev/null)" = 09 ] && continue      # sin hubs
  i=$((i+1)); v=$(cat "$d/idVendor"); p=$(cat "$d/idProduct")
  echo "$i) $v:$p  $(cat "$d/manufacturer" 2>/dev/null) $(cat "$d/product" 2>/dev/null)"
  echo "$i $v $p" >> "$C/.usb.lst"
done
[ "$i" -gt 0 ] || { echo "No veo dispositivos USB compartidos con Linux."; exit 1; }
printf 'Numero del telefono: '; read n
l=$(awk -v n="$n" '$1==n {print $2" "$3}' "$C/.usb.lst"); rm -f "$C/.usb.lst"
[ -n "$l" ] || { echo "Opcion no valida."; exit 1; }
echo "$l" > "$C/telefono"; echo "Guardado. Arranca la VM con ./quick-test.sh (o el icono)."
