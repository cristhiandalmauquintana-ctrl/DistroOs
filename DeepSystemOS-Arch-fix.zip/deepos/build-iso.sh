#!/bin/sh
# Construye la ISO real de DeepSystemOS (Arch Linux + archiso) dentro de un contenedor Arch (podman o docker).
# Resultado: out/*.iso      Necesita ~8 GB libres y internet. La primera vez tarda (descarga ~1.5 GB); las siguientes son mas rapidas
# porque los paquetes se guardan en cache/pkg.
#   LITE=1 ./build-iso.sh     version ligera (sin Firefox ni herramientas extra)
#   FAST=1 ./build-iso.sh     modo rapido para desarrollo: SquashFS con zstd en vez de xz (construye mucho mas rapido y arranca
#                             mas agil en QEMU; la ISO sale algo mas grande). Para la ISO final, sin FAST.
set -e
# archiso necesita montar cosas (pacstrap): hace falta administrador. Se pide sudo solo.
if [ "$(id -u)" != 0 ]; then
  echo ">> Se necesita administrador para construir la ISO; pidiendo sudo..."
  exec sudo -E "$0" "$@"
fi
HERE=$(cd "$(dirname "$0")" && pwd)
ENG=$(command -v podman || command -v docker || true)
[ -n "$ENG" ] || { echo "Falta podman o docker. Instala: sudo apt install podman"; exit 1; }
mkdir -p "$HERE/cache/pkg" "$HERE/out"
command -v ssh-keygen >/dev/null || { echo "Falta openssh-client: sudo apt install openssh-client"; exit 1; }
[ -f "$HERE/cache/id_deep" ] || ssh-keygen -t ed25519 -N "" -q -f "$HERE/cache/id_deep"
echo ">> Construyendo DeepSystemOS (Arch Linux). Esto tarda; la primera vez mas."
$ENG run --rm --privileged --network=host -t \
  -v "$HERE":/deepos -v "$HERE/out":/out -v "$HERE/cache/pkg":/var/cache/pacman/pkg \
  -e LITE="${LITE:-0}" -e FAST="${FAST:-0}" \
  docker.io/library/archlinux:latest bash /deepos/build/inside.sh
echo ">> Listo:"; ls -lh "$HERE/out"/*.iso
[ -n "$SUDO_USER" ] && chown -R "$SUDO_USER": "$HERE/out" "$HERE/cache" 2>/dev/null
echo ">> Para liberar espacio: sudo $ENG system prune -a"
