#!/bin/sh
# Diagnostico de entrada (raton/teclado), Xorg y servicios (por SSH, con la VM en marcha)
D=$(cd "$(dirname "$0")" && pwd)
"$D/ssh.sh" '
echo "--- preparacion del sistema"; tail -n 20 /var/log/deepsystemos-firstboot.log
echo "--- servicios con fallos"; systemctl --failed --no-legend
echo "--- Xorg (EE)"; grep "(EE)" /var/log/Xorg.0.log /root/.local/share/xorg/Xorg.0.log 2>/dev/null | head -25
echo "--- dispositivos de entrada"; ls /dev/input
echo "--- red"; networkctl --no-pager 2>/dev/null | head -10
echo "--- sonido"; aplay -l 2>&1 | head -8
echo "--- startx"; tail -n 15 /tmp/startx.log
echo "--- paquetes"; pacman -Q xf86-input-libinput xorg-server openbox 2>&1
'
