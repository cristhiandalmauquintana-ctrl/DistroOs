#!/bin/sh
# Copia tus cambios de overlay/ a la VM que ya esta corriendo, SIN reconstruir la ISO (segundos en vez de minutos).
#   ./sync.sh                                   copia usr/ y etc/
#   ./sync.sh usr/local/bin/deep-tienda         copia solo esa ruta (puedes poner varias)
#   ./sync.sh root/.config/openbox              rutas de root/ (ojo: pisan lo que hayas cambiado dentro de la VM)
# Sirve para scripts, menus, traducciones, catalogos y configuracion. NO sirve para paquetes (packages*.txt): eso si pide reconstruir.
# Necesita la VM abierta (./run-iso.sh) y que la ISO se haya construido con la llave SSH (build-iso.sh la crea sola).
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE/overlay" || exit 1
[ $# -gt 0 ] || set -- usr etc
tar -cf - "$@" | "$HERE/ssh.sh" 'tar -xf - -C / --no-same-owner && chmod 755 /usr/local/bin/* /usr/local/sbin/* 2>/dev/null; systemctl daemon-reload; DISPLAY=:0 openbox --reconfigure 2>/dev/null; echo ">> Listo: cambios copiados a la VM (cierra y abre la app para verlos)"'
